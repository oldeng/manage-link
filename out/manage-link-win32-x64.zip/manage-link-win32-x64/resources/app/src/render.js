const { ipcRenderer } = require("electron");
// import Vue from 'vue';
// console.log('243234',Vue);
window.ipcRenderer = ipcRenderer;

// module.exports = ipcRenderer;