module.exports = {
    publicPath: './'
}